import logging
from datetime import datetime
from requests.auth import HTTPBasicAuth
from Cloud.cloud import JiraCloud
import time
import os
import json
from datetime import datetime
from csv import DictReader
from threading import Thread
from threading import Event
import os
from queue import Queue
from dotenv import load_dotenv
load_dotenv()

SERVER_URL = os.getenv("SERVER_URL")
SERVER_USER = os.getenv("SERVER_USER")
SERVER_PASSWORD = os.getenv("SERVER_PASSWORD")
NUM_THREADS = 50
q = Queue()
event = Event()

def updateBatch():
    logging.info("Start Thread")
    global q
    while q.qsize() > 0:
        issue = q.get()
        fieldsValue = {}
        for i in issue:
            if issue[i] and i != 'issuekey' and i != 'customfield_10324':
                    fieldsValue.update({i : [{"id": issue[i]}]})
            if fieldsValue:
                print(fieldsValue)
                payload = json.dumps({
                    "fields": fieldsValue
                })
                time.sleep(3)
                issueUpdateStatus = JiraCloud.updateIssue(issue['issuekey'],payload)
                if issueUpdateStatus == 204:
                    logging.info("Issue restantes: " + str(q.qsize()))
                elif issueUpdateStatus == 429:
                     q.task_done()
                     logging.info("Issue enviada para reprocessamento")
                
        if event.is_set():
            q.task_done()
            raise Exception('Received request to halt')         
        q.task_done()             


if __name__ == '__main__': 
    start = time.time()
    cloud = JiraCloud()
    now = datetime.now()
    dt_string = now.strftime("%H:%M:%S")
    filenamec = dt_string + ".log"
    log_dir = os.path.join(os.path.normpath(os.getcwd() + os.sep + os.pardir), './logs/ExecuteMigrationLogs')
    log_fname = os.path.join(log_dir, filenamec)
    logging.basicConfig(filename=log_fname, encoding='utf-8', level=logging.DEBUG, format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
    logging.info("##################################################################  Lendo Arquivos ##################################################################")
    index = 0
    
    def dict_filter(it, *keys):
        for d in it:
            yield dict((k, d[k]) for k in keys)

    list_of_dict = []
    directory = os.path.join(os.path.normpath(os.getcwd() + os.sep + os.pardir), './data')
    for root,dirs,files in os.walk(directory):
        for file in files:
            if file.endswith(".csv"):
                fileName = '../data/'+file
                print(fileName)
                with open(fileName) as csv_file:
                        dict_reader = DictReader(csv_file)
                        list_of_dict = list(dict_reader)
                        print(len(list_of_dict))    

    for listIssues in list_of_dict:
           q.put(listIssues)

    logging.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    logging.info("tamanho da fila: " + str( q.qsize()))
    logging.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for t in range(NUM_THREADS):

            worker = Thread(target=updateBatch)
            worker.daemon = True
            worker.start()
     
    
   # threads = [Thread(target=updateBatch) for _ in range(NUM_THREADS)]
   # for thread in threads:
   #     thread.daemon=True
   #[thread.start() for thread in threads]
   #for thread in threads:
   #    thread.join()
     
    q.join()

    end = time.time()
    
    def calculateTimeInSeconds(startTime, endTime):
        return startTime - endTime
    
    def convertSeconToMinutos(seconds):
        return seconds // 60

    def calculateExecutionTime(startTime, endTime):
        seconds = calculateTimeInSeconds(startTime,endTime)
        minutes = convertSeconToMinutos(seconds)
        hour = (seconds // 3600)
        return f"Time to excution in Hours: {hour} in Minutes: {minutes} in Seconds: {seconds}"

    executionTime = calculateExecutionTime(start, end)
    logging.info(executionTime)
   
