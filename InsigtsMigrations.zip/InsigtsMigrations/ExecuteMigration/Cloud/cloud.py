import json
import logging
import requests
from requests.auth import HTTPBasicAuth
import os
from dotenv import load_dotenv
load_dotenv()

CLOUD_URL = os.getenv("CLOUD_URL")
JSM_URL = os.getenv("JSM_URL")

class JiraCloud:

    def getInsightObject(serverId):
        logging.info(f"Call Cloud api to get object key")
        url =  os.getenv("JSM_URL")
        auth = HTTPBasicAuth(os.getenv("CLOUD_USER"), os.getenv("CLOUD_PASSWORD"))
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        query = {
            'qlQuery': f'"Server Key" = {serverId}'
        }
        try:
            response = requests.request(
                "GET",
                url,
                headers=headers,
                params=query,
                auth=auth
            )
            return response.json()
        except requests.exceptions.RequestException as e:
            print(e)
            logging.info(f"Error when get objetc  {e} ")

    def updateIssue(key,payload):
        authCloud = HTTPBasicAuth("felipe.carneiro@e-core.com", "Yw52Vm7ZjaW8HEPuFQ0F2A65")

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        url_Update = f"{CLOUD_URL}/rest/api/3/issue/{key}"
        
        logging.info(f'Update issue {key}')
        logging.info(payload)
        
        response = requests.request(
            "PUT",
            url_Update,
            data=payload,
            headers=headers,
            auth=authCloud
        )
        logging.info(f'{response.text}')
        logging.info("*******************************************")
        return response.status_code