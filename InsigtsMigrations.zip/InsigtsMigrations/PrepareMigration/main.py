import logging
from datetime import datetime
from requests.auth import HTTPBasicAuth
from Server.server import JiraServer
from Cloud.cloud import JiraCloud
from Util.util import Util
import time
from threading import Thread
from threading import Event
import os
import csv
from datetime import datetime
from dotenv import load_dotenv
from queue import Queue
load_dotenv()

SERVER_URL = os.getenv("SERVER_URL")
SERVER_USER = os.getenv("SERVER_USER")
SERVER_PASSWORD = os.getenv("SERVER_PASSWORD")

serverUrl = SERVER_URL

serverAuth = HTTPBasicAuth(SERVER_USER, SERVER_PASSWORD)

headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}
serverCustomFieldList = {
        'Aplicação':'customfield_10604',
        'Aplicações Movida': 'customfield_10633',
        'Cargo':'customfield_10805',
        'Centro de Custo':'customfield_10808',
        'Dados do Cliente':'customfield_10548',
        'Dados do Colaborador':'customfield_12244',
        'Dados do Responsável':'customfield_12300',
        'DDD':'customfield_10807',
        'Desktop':'customfield_10573',
        'E-mail (Insight - E-mail)':'customfield_10704',
        'Equipamento':'customfield_10578',
        'Erro - TEF':'customfield_11000',
        'Filial Destino':'customfield_10628',
        'Filial Destino Equipamento':'customfield_11900',
        'Fornecedor':'customfield_10723',
        'Gestor':'customfield_10806',
        'Loja':'customfield_10570',
        'Navegador':'customfield_10587',
        'Notebook':'customfield_10572',
        'Plugin':'customfield_11203',
        'Plugin Insight':'customfield_11603',
        'Problemas de Aplicações':'customfield_12241',
        'Problemas de Equipamentos':'customfield_12243',
        'Problemas de Internet e Telefonia':'customfield_12242',
        'Responsável Legal':'customfield_12209',
        'Responsável pela Abertura':'customfield_10724',   
        'Responsável Validação GMUD':'customfield_10717',
        'Servidor':'customfield_10555',
        'Servidor BD':'customfield_10551',
        'Servidores da Aplicação':'customfield_10606',
        'Sistema':'customfield_10562',
        'Sistemas acesso':'customfield_10814',
        'Sistemas que o colaborador tinha acesso':'customfield_12236',
        'Smartphone':'customfield_10634',
        'Software':'customfield_10588',
        'Tablet':'customfield_10575',
        'Tipo de Ação - Aplicações':'customfield_12238',
        'Tipo de Ação - Equipamentos':'customfield_12240',
        'Tipo de Ação - Internet e Telefonia':'customfield_12239',
        'Tipo de Equipamento':'customfield_10565',
        'Tipo de Solicitacao':'customfield_12500',
        'Usuário Destino':'customfield_10629',
        'Usuário(s)':'customfield_10583'
    }
cloudCustomFieldList = {
        'Aplicação':'customfield_10187',
        'Aplicações Movida': 'customfield_10176',
        'Cargo':'customfield_10188',
        'Centro de Custo':'customfield_10189',
        'Dados do Cliente':'customfield_10039',
        'Dados do Colaborador':'customfield_10192',
        'Dados do Responsável':'customfield_10193',
        'DDD':'customfield_10190',
        'Desktop':'customfield_10194',
        'E-mail (Insight - E-mail)':'customfield_10195',
        'Equipamento':'customfield_10134',
        'Erro - TEF':'customfield_10197',
        'Filial Destino':'customfield_10198',
        'Filial Destino Equipamento':'customfield_10199',
        'Fornecedor':'customfield_10200',
        'Gestor':'customfield_10186',
        'Loja':'customfield_10178',
        'Navegador':'customfield_10201',
        'Notebook':'customfield_10202',
        'Plugin':'customfield_10203',
        'Plugin Insight':'customfield_10204',
        'Problemas de Aplicações':'customfield_10182',
        'Problemas de Equipamentos':'customfield_10183',
        'Problemas de Internet e Telefonia':'customfield_10184',
        'Responsável Legal':'customfield_10205',
        'Responsável pela Abertura':'customfield_10207',   
        'Responsável Validação GMUD':'customfield_10206',
        'Servidor':'customfield_10208',
        'Servidor BD':'customfield_10209',
        'Servidores da Aplicação':'customfield_10210',
        'Sistema':'customfield_10211',
        'Sistemas acesso':'customfield_10185',
        'Sistemas que o colaborador tinha acesso':'customfield_10212',
        'Smartphone':'customfield_10213',
        'Software':'customfield_10214',
        'Tablet':'customfield_10215',
        'Tipo de Ação - Aplicações':'customfield_10179',
        'Tipo de Ação - Equipamentos':'customfield_10180',
        'Tipo de Ação - Internet e Telefonia':'customfield_10181',
        'Tipo de Equipamento':'customfield_10216',
        'Tipo de Solicitacao':'customfield_10177',
        'Usuário Destino':'customfield_10217',
        'Usuário(s)':'customfield_10218'
    }
NUM_THREADS = 50
q = Queue()
dic_csv = []
event = Event()

def get_Object_Id():
    logging.info("Start Thread")
    global q
    
    idx = 0
    while True:
        sleep = 3
        issue = q.get()
        row = {}
        idx +=1
        time.sleep(3)
        row['issuekey'] = issue['key']
        logging.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        logging.info(f"Issue key {issue['key']}")
        logging.info(f'Issue Restantes {q.qsize()}')
        for key in serverCustomFieldList:
            if serverCustomFieldList[key] in issue['fields']:
                if issue['fields'][serverCustomFieldList[key]] is None:
                        row[cloudCustomFieldList[key]]= ''
                else:
                         serverObjectId = "IM"+Util.getStringId(issue['fields'][serverCustomFieldList[key]][0])
                         insightObject = JiraCloud.getInsightObject(serverObjectId)
                         serverObjectId = "IM"+Util.getStringId(issue['fields'][serverCustomFieldList[key]][0])
                         time.sleep(sleep)
                         response = JiraCloud.getInsightObject(serverObjectId)
                         insightObject = response.json()
                         if response.status_code == 200:
                                logging.info(f"serverObjectId {serverObjectId}")
                                try:
                                    if 'objectEntries' in insightObject:
                                        if len(insightObject['objectEntries']) > 0 :
                                            logging.info("Insight Object ID: " + insightObject['objectEntries'][0]['globalId'])
                                            row[cloudCustomFieldList[key]]=  insightObject['objectEntries'][0]['globalId']
                                        else:
                                            logging.info("Insight Object ID: NULL")
                                            row[cloudCustomFieldList[key]]= ''
                                    else:
                                        logging.info("Insight Object ID: NULL")
                                        row[cloudCustomFieldList[key]]= ''
                                except ValueError:
                                        print("errr")
                                        logging.info(f'Error to get object id: on cloud')
                                logging.info(row)
                         elif response.status_code == 429:
                                logging.info(f'Enviada para reprocessamento')
                                q.task_done()
                                sleep +=1 

        if event.is_set():
            q.task_done()
            raise Exception('Received request to halt')   
        dic_csv.append(row)
        q.task_done()


if __name__ == '__main__':
    
    JQL = os.getenv("JQL")
    start = time.time()
    server = JiraServer(serverUrl, headers, serverAuth)
    cloud = JiraCloud()
    now = datetime.now()
    dt_string = now.strftime("%H:%M:%S")
    filenamec = dt_string + ".log"
    log_dir = os.path.join(os.path.normpath(os.getcwd() + os.sep + os.pardir), './logs/PrepareLogs')
    log_fname = os.path.join(log_dir, filenamec)
    logging.basicConfig(filename=log_fname, encoding='utf-8', level=logging.DEBUG, format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
    logging.info("################################################################## Iniciando Migração Insight##################################################################")
    logging.info("Base URL: " + serverUrl)
    logging.info("JQL: " + JQL)
    issueList = server.searchJql(JQL, 0)
    index = 0
    threads = 25

    header = ['issuekey']
    
    now = datetime.now()
    dt_string = now.strftime("%d-%m-%H_%M_%S")
    csv_file = os.path.join(os.path.normpath(os.getcwd() + os.sep + os.pardir), f'./data/PrepareMigratio_{dt_string}.csv')
    
    for cf in cloudCustomFieldList:
        header.append(cloudCustomFieldList[cf])

    for listIssues in issueList:
        for issue in listIssues:
              q.put(issue)
    logging.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    logging.info("tamanho da fila: " + str( q.qsize()))
    logging.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for t in range(NUM_THREADS):

            worker = Thread(target=get_Object_Id)
            worker.daemon = True
            worker.start()

    q.join()

    try:
            with open(csv_file, 'a') as f_object:
                    writer = csv.DictWriter(f_object, fieldnames=header)
                    writer.writeheader()
                    for data in dic_csv:
                        writer.writerow(data)
                    f_object.close()
    except IOError as e:
                print("I/O error" )
                logging.info("I/O error" + e)
                print(e)      

    end = time.time()   




def calculateTimeInSeconds(startTime, endTime):
        return startTime - endTime
    
def convertSeconToMinutos(seconds):
        return seconds // 60

def calculateExecutionTime(startTime, endTime):
        seconds = calculateTimeInSeconds(startTime,endTime)
        minutes = convertSeconToMinutos(seconds)
        hour = (seconds // 3600)
        return f"Time to excution in Hours: {hour} in Minutes: {minutes} in Seconds: {seconds}"

executionTime = calculateExecutionTime(start, end)
logging.info(executionTime)
   
