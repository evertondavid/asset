import datetime
import re

class Util:

    def __init__(self):
            print("in init")

    def getStringId(text):
        pattern = "\(IM(.*?)\)"
        result = re.search(pattern, text)
        return result.group(1)
    
    def calculateTimeInSeconds(self,startTime, endTime):
        return startTime - endTime
    
    def convertSeconToMinutos(self,seconds):
        return str(datetime.timedelta(seconds=seconds))

    def calculateExecutionTime(self,startTime, endTime):
        seconds = self.calculateTimeInSeconds(startTime,endTime)
        minutes = self.convertSeconToMinutos(seconds)
        hour = (seconds // 3600)
        return f"Time to excution in Hours: {hour} in Minutes: {minutes} in Seconds: {seconds}"

