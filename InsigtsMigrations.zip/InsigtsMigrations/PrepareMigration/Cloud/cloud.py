import json
import logging
import requests
from requests.auth import HTTPBasicAuth
from dotenv import load_dotenv
import os
load_dotenv()
CLOUD_URL = os.getenv("CLOUD_URL")

class JiraCloud:

    

    def getInsightObject(serverId):
        logging.info(f"Call Cloud api to get object key")
        url = "https://api.atlassian.com/jsm/assets/workspace/a99bd9c5-1d4c-4470-a0c2-01e236ad55c0/v1/aql/objects"
        auth = HTTPBasicAuth("felipe.carneiro@e-core.com", "Yw52Vm7ZjaW8HEPuFQ0F2A65")
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        query = {
            'qlQuery': f'"Server Key" = {serverId}'
        }
        try:
            response = requests.request(
                "GET",
                url,
                headers=headers,
                params=query,
                auth=auth
            )
            return response
        except requests.exceptions.RequestException as e:
            print(e)
            logging.info(f"Error when get objetc  {e} ")

    def updateIssue(key,customFieldId,objectKey):
        authCloud = HTTPBasicAuth("felipe.carneiro@e-core.com", "Yw52Vm7ZjaW8HEPuFQ0F2A65")

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        url_Update = f"{CLOUD_URL}/rest/api/3/issue/{key}"
        payload = json.dumps({
            "fields": {
            customFieldId : [{"id": objectKey}],
            }
        })

        print(payload)
        print(url_Update)

        response = requests.request(
            "PUT",
            url_Update,
            data=payload,
            headers=headers,
            auth=authCloud
        )
        return response.status_code