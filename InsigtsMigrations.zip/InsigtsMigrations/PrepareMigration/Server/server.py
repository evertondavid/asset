# http://docs.python-requests.org
import logging
import requests
from requests.auth import HTTPBasicAuth


class JiraServer:

    def __init__(self, url, headers, auth):
        self.url = url
        self.headers = headers
        self.auth = auth

    def getIssue(self, query, startAt):
        query = {
            'jql': query,
            'maxResults': 1000,
            'startAt': startAt
        }
        response = requests.request(
            "GET",
            self.url,
            headers=self.headers,
            params=query,
            auth=self.auth
        )
        return response.json()

    def searchJql(self, query, startAt):
        issues = []
        startAt = 0
        issueRequest = self.getIssue(query, startAt)
        issues.append(issueRequest["issues"])
        total = issueRequest["total"]
        logging.info(f'TOTAL DE ISSUES RETORNADAS: {total}' )
        i = 0
        if total > 1000:
            while total > 1000 + startAt - 1:
                i = i+1000
                startAt = startAt + 1000
                issueRequestt = self.getIssue(query, startAt)
                issues.append(issueRequestt["issues"])
                logging.info(f"Pegando páginas: {i} Total de: {total}")
        return issues